import numpy as np
from scipy.optimize import minimize

def ejercicio1():
    print("\n--- Ejercicio 1 ---")
    print("Minimizar f(x1,x2) = x1² + 2x2²")
    print("Restricción: x1 + 2x2 - 3 ≤ 0")
    
    def objetivo(x):
        return x[0]**2 + 2*x[1]**2
    
    def restriccion(x):
        return 3 - x[0] - 2*x[1]
    
    # Condiciones iniciales
    x0 = [0, 0]
    
    # Restricciones
    restricciones = {'type': 'ineq', 'fun': restriccion}
    
    # Resolver
    resultado = minimize(objetivo, x0, method='SLSQP', constraints=[restricciones])
    
    print("\nResultados:")
    print(f"x1 óptimo: {resultado.x[0]:.4f}")
    print(f"x2 óptimo: {resultado.x[1]:.4f}")
    print(f"Valor mínimo: {resultado.fun:.4f}")

def ejercicio2():
    print("\n--- Ejercicio 2 ---")
    print("Minimizar f(x1,x2) = x1² + x2²")
    print("Restricciones: x1 + x2 - 2 ≤ 0, x1 ≥ 0")
    
    def objetivo(x):
        return x[0]**2 + x[1]**2
    
    def restriccion1(x):
        return 2 - x[0] - x[1]
    
    def restriccion2(x):
        return x[0]
    
    # Condiciones iniciales
    x0 = [0, 0]
    
    # Restricciones
    restricciones = [
        {'type': 'ineq', 'fun': restriccion1},
        {'type': 'ineq', 'fun': restriccion2}
    ]
    
    # Resolver
    resultado = minimize(objetivo, x0, method='SLSQP', constraints=restricciones)
    
    print("\nResultados:")
    print(f"x1 óptimo: {resultado.x[0]:.4f}")
    print(f"x2 óptimo: {resultado.x[1]:.4f}")
    print(f"Valor mínimo: {resultado.fun:.4f}")

def ejercicio3():
    print("\n--- Ejercicio 3 ---")
    print("Maximizar f(x1,x2) = 3x1 + 4x2")
    print("Restricciones: x1² + x2² ≤ 9, x1 ≥ 0, x2 ≥ 0")
    
    def objetivo_negativo(x):
        return -(3*x[0] + 4*x[1])
    
    def restriccion1(x):
        return 9 - (x[0]**2 + x[1]**2)
    
    def restriccion2(x):
        return x[0]
    
    def restriccion3(x):
        return x[1]
    
    # Condiciones iniciales
    x0 = [0, 0]
    
    # Restricciones
    restricciones = [
        {'type': 'ineq', 'fun': restriccion1},
        {'type': 'ineq', 'fun': restriccion2},
        {'type': 'ineq', 'fun': restriccion3}
    ]
    
    # Resolver
    resultado = minimize(objetivo_negativo, x0, method='SLSQP', constraints=restricciones)
    
    print("\nResultados:")
    print(f"x1 óptimo: {resultado.x[0]:.4f}")
    print(f"x2 óptimo: {resultado.x[1]:.4f}")
    print(f"Valor máximo: {-(resultado.fun):.4f}")

def main():
    print("Solver de Condiciones Karush-Kuhn-Tucker (KKT)")
    ejercicio1()
    ejercicio2()
    ejercicio3()

if __name__ == "__main__":
    main()